return {
	ZK = {
		Nuclear_Winter_v1 = 17.6538067,
	},
}
