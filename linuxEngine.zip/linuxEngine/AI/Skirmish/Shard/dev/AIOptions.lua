--
-- Custom Options Definition Table format
--
-- A detailed example of how this format works can be found
-- in the spring source under:
-- AI/Skirmish/NullAI/data/AIOptions.lua
--
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------

local options = {
	--{ -- string
	--	key     = 'performancetimers',
	--	name    = 'Performance Lag Timers',
	--	desc    = 'Will log times and display times if spikes occur or heavy load is encountered',
	--	type    = 'bool',
	--	def     = false,
	--},
}

return options

