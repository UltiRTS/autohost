--[[
Attackers!
]]--

attackerlist = {
	"corak",
	"armpw",
	"corgator",
	"corthud",
	"corkrog",
	"armham",
	"armrock",
	"armpw",
	"armfav",
	"armflash",
	"armstump",
	"armjanus",
	"armham",
	"TAWF013",
	"armjeth",
	"armwar",
	"armhawk",
	"armfig",
	"armpnix",
	
}
