--[[
Attackers!
]]--

attackerlist = {
	"corak",
	"armpw",
	"corgator",
	"corthud",
	"corkrog",
	"armham",
	"corraid",
}
