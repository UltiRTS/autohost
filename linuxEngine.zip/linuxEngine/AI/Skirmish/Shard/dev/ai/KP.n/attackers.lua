--[[
Attackers!
]]--

attackerlist = {
	"bit",
	"byte",
	"dos",
	"pointer",
	"mineblaster",
	"bug",
	"worm",
}
