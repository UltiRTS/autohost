function shardify_unittype( unittype )
	return unittype
end