--[[
Attackers!
]]--

attackerlist = {
	"bit",
	"bug",
	"bugold",
	"packet",
	"virus",
	"fairy",
	"byte",
	"worm",
	"wormold",
	"connection",
	"reimu",
	"pointer",
	"dos",
	"flow",
	"marisa",
}
