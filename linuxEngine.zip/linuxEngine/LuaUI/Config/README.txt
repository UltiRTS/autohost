
This is where the LuaUI configuration files for the
Widget Manager and Widgets are stored. They are not
overwritten during game upgrades or updates.

